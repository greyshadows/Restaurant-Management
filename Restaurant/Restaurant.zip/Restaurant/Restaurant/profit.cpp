#include "StdAfx.h"
#include "profit.h"

