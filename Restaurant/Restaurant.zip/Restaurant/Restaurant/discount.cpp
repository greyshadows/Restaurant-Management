#include "StdAfx.h"
#include "discount.h"

