#include "StdAfx.h"
#include "CustomerList.h"

