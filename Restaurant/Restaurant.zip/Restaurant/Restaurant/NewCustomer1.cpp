#include "StdAfx.h"
#include "NewCustomer1.h"

