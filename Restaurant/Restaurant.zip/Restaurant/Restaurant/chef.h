#pragma once

namespace Restaurant {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;
	/// <summary>
	/// Summary for chef
	/// </summary>
	public ref class chef : public System::Windows::Forms::Form
	{
	public:
		int completed;
		int num;
		chef(void)
		{
			InitializeComponent();
			completed = 1;
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~chef()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::ListView^  listView1;
	protected: 
	private: System::Windows::Forms::ColumnHeader^  columnHeader1;


	private: System::Windows::Forms::ColumnHeader^  columnHeader4;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;

	private: System::Windows::Forms::ColumnHeader^  columnHeader6;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Label^  label7;

	private: System::Windows::Forms::Label^  label9;

	private: System::Windows::Forms::ListBox^  listBox1;
	private: System::Windows::Forms::Label^  label10;
	private: System::Windows::Forms::RichTextBox^  richTextBox1;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::ColumnHeader^  columnHeader2;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->listView1 = (gcnew System::Windows::Forms::ListView());
			this->columnHeader2 = (gcnew System::Windows::Forms::ColumnHeader());
			this->columnHeader1 = (gcnew System::Windows::Forms::ColumnHeader());
			this->columnHeader4 = (gcnew System::Windows::Forms::ColumnHeader());
			this->columnHeader6 = (gcnew System::Windows::Forms::ColumnHeader());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->listBox1 = (gcnew System::Windows::Forms::ListBox());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->richTextBox1 = (gcnew System::Windows::Forms::RichTextBox());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// listView1
			// 
			this->listView1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left) 
				| System::Windows::Forms::AnchorStyles::Right));
			this->listView1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::ColumnHeader^  >(4) {this->columnHeader2, this->columnHeader1, 
				this->columnHeader4, this->columnHeader6});
			this->listView1->Font = (gcnew System::Drawing::Font(L"Lucida Sans Typewriter", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->listView1->FullRowSelect = true;
			this->listView1->GridLines = true;
			this->listView1->Location = System::Drawing::Point(12, 12);
			this->listView1->Name = L"listView1";
			this->listView1->Size = System::Drawing::Size(829, 146);
			this->listView1->TabIndex = 3;
			this->listView1->UseCompatibleStateImageBehavior = false;
			this->listView1->View = System::Windows::Forms::View::Details;
			// 
			// columnHeader2
			// 
			this->columnHeader2->Text = L"Bill Number";
			this->columnHeader2->Width = 120;
			// 
			// columnHeader1
			// 
			this->columnHeader1->Text = L"Item Name";
			this->columnHeader1->Width = 305;
			// 
			// columnHeader4
			// 
			this->columnHeader4->Text = L"Amount Ordered";
			this->columnHeader4->Width = 262;
			// 
			// columnHeader6
			// 
			this->columnHeader6->Text = L"Packing";
			this->columnHeader6->Width = 237;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(322, 164);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(193, 51);
			this->button1->TabIndex = 4;
			this->button1->Text = L"Accept Order";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &chef::button1_Click);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Italic, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(361, 231);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(106, 20);
			this->label5->TabIndex = 8;
			this->label5->Text = L"Current Order";
			this->label5->Visible = false;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Italic, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(60, 266);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(87, 20);
			this->label1->TabIndex = 9;
			this->label1->Text = L"Item Name";
			this->label1->Visible = false;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Italic, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(60, 331);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(89, 20);
			this->label2->TabIndex = 10;
			this->label2->Text = L"Description";
			this->label2->Visible = false;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Italic, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(515, 308);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(89, 20);
			this->label3->TabIndex = 11;
			this->label3->Text = L"Ingredients";
			this->label3->Visible = false;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Italic, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(61, 447);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(65, 20);
			this->label4->TabIndex = 12;
			this->label4->Text = L"Amount";
			this->label4->Visible = false;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Italic, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label6->Location = System::Drawing::Point(61, 386);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(65, 20);
			this->label6->TabIndex = 13;
			this->label6->Text = L"Packing";
			this->label6->Visible = false;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(184, 271);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(35, 13);
			this->label7->TabIndex = 14;
			this->label7->Text = L"label7";
			this->label7->Visible = false;
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Location = System::Drawing::Point(184, 391);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(35, 13);
			this->label9->TabIndex = 16;
			this->label9->Text = L"label9";
			this->label9->Visible = false;
			// 
			// listBox1
			// 
			this->listBox1->FormattingEnabled = true;
			this->listBox1->Location = System::Drawing::Point(627, 266);
			this->listBox1->Name = L"listBox1";
			this->listBox1->Size = System::Drawing::Size(129, 134);
			this->listBox1->TabIndex = 18;
			this->listBox1->Visible = false;
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Location = System::Drawing::Point(184, 452);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(41, 13);
			this->label10->TabIndex = 17;
			this->label10->Text = L"label10";
			this->label10->Visible = false;
			// 
			// richTextBox1
			// 
			this->richTextBox1->Location = System::Drawing::Point(188, 308);
			this->richTextBox1->Name = L"richTextBox1";
			this->richTextBox1->ReadOnly = true;
			this->richTextBox1->Size = System::Drawing::Size(234, 68);
			this->richTextBox1->TabIndex = 19;
			this->richTextBox1->Text = L"";
			this->richTextBox1->Visible = false;
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(322, 452);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(193, 51);
			this->button2->TabIndex = 20;
			this->button2->Text = L"Order Completed";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &chef::button2_Click);
			// 
			// chef
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(868, 506);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->richTextBox1);
			this->Controls->Add(this->listBox1);
			this->Controls->Add(this->label10);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->listView1);
			this->Name = L"chef";
			this->Text = L"chef";
			this->Load += gcnew System::EventHandler(this, &chef::chef_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	
	private: System::Void fillList(){
				 String^ connectString=L"datasource=127.0.0.1;port=3306;username=root;password=abc123";
				 MySqlConnection^ conDatabase= gcnew MySqlConnection(connectString);
				 MySqlCommand^ cmdDatabase= gcnew MySqlCommand("SELECT * FROM `restaurant`.`order` WHERE `order`.`status` = 'not_delivered';",conDatabase);
				 MySqlDataReader^ myReader;
				 try{
					 conDatabase->Open();
					 myReader = cmdDatabase->ExecuteReader();
					 int k=0;
					 listView1->Items->Clear();
					 while(myReader->Read()){
						 if(k==0){
							 num = myReader->GetInt32(0);
						 }
						 
						 ListViewItem^ obj = listView1->Items->Add(myReader->GetString(2));
						 obj->SubItems->Add(myReader->GetString(5));
						 obj->SubItems->Add(myReader->GetString(6));
						 obj->SubItems->Add(myReader->GetString(8));
						 k++;
					 }
				 }
				 catch(Exception^ ex){
					 MessageBox::Show(ex->Message,"Error");
				 }
				 conDatabase->Close();
				 }
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
				 if(completed == 1 && listView1->Items->Count != 0){
					 completed = 0;
				 label1->Visible = true;
				 label2->Visible = true;
				 label3->Visible = true;
				 label4->Visible = true;
				 label5->Visible = true;
				 label6->Visible = true;
				 label7->Visible = true;
				 label9->Visible = true;
				label10->Visible = true;
				 listBox1->Visible = true;
				 richTextBox1->Visible = true;
				 ListViewItem^ obj = listView1->Items[0];
				 String^ itName = obj->SubItems[1]->Text;
				 String^ connectString=L"datasource=127.0.0.1;port=3306;username=root;password=abc123";
				 MySqlConnection^ conDatabase= gcnew MySqlConnection(connectString);
				 MySqlCommand^ cmdDatabase= gcnew MySqlCommand("SELECT * FROM `restaurant`.`menu` WHERE `menu`.`itemName` = '"+itName+"';",conDatabase);
				 MySqlDataReader^ myReader;
				 try{
					 conDatabase->Open();
					 myReader = cmdDatabase->ExecuteReader();
					 listBox1->Items->Clear();
					 while(myReader->Read()){
						 label10->Text = obj->SubItems[2]->Text;
						 label9->Text = obj->SubItems[3]->Text;
						 label7->Text = myReader->GetString(1);
						 richTextBox1->Text = myReader->GetString(2);
						 int j=0;
						 String^ des = myReader->GetString(5);
						 for(int i=0;i<(des->Length);i++){
							  if(des[i] == ')'){
								 String^ temp = des->Substring(j,i+1-j);
								 listBox1->Items->Add(temp);

								 j=i+2;
							 }
						 }
						
					 }
				 }
				 catch(Exception^ ex){
					 MessageBox::Show(ex->Message,"Error");
				 }
				 conDatabase->Close();
				 }else{
					 MessageBox::Show("Complete the previous order first. If completed there are no remaining orders","Error");
				 }
				 }
private: System::Void chef_Load(System::Object^  sender, System::EventArgs^  e) {
			 fillList();
		 }
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
			 String^ connectString=L"datasource=127.0.0.1;port=3306;username=root;password=abc123";
			 MySqlConnection^ conDatabase= gcnew MySqlConnection(connectString);
			 MySqlCommand^ cmdDatabase= gcnew MySqlCommand("UPDATE `restaurant`.`order` SET `order`.`status` = 'delivered' WHERE `order`.`number` = '"+num+"';",conDatabase);
			 MySqlDataReader^ myReader;
			 try{
				 conDatabase->Open();
				 myReader = cmdDatabase->ExecuteReader();
			 }
			 catch(Exception^ ex){
				 MessageBox::Show(ex->Message,"Error");
			 }
			 conDatabase->Close();
			 
		
			 
			 completed = 1;
			 fillList();
			 label1->Visible = false;
			 label2->Visible = false;
			 label3->Visible = false;
			 label4->Visible = false;
			 label5->Visible = false;
			 label6->Visible = false;
			 label7->Visible = false;
			 label9->Visible = false;
			 label10->Visible = false;
			 listBox1->Visible = false;
			 richTextBox1->Visible = false;
		 

		 }
};
}
